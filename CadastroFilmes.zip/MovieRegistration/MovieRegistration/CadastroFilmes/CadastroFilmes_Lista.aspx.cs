﻿using CadastroFilme;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;

namespace CadastroFilmes.CadastroFilmes
{
    public partial class CadastroFilmes_Lista : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Realiza trecho somente se não for primeira vez que a página é carregada
            if (!Page.IsPostBack)

            //Função para carregar a lista de filmes
            CarregaListaFilmes();

        }

        protected void CarregaListaFilmes()
        {
            //Carrega todos filmes
            using (RegistroFilmesEntities dc = new RegistroFilmesEntities())
            {
                //Select utilizando LINQ
                GridViewFilme.DataSource = dc.Filme.ToList();
                GridViewFilme.DataBind();
            }
            
        }
        protected void AdicionarFilme_Click(object sender, EventArgs e)
        {
            //Ao clicar no Botão Adicionar filme, o usuário é levado para a página de cadastro de filmes
            Response.Redirect("CadastroFilmes_Edita.aspx");
        }

        protected void AdicionarGenero_Click(object sender, EventArgs e)
        {
            //Ao clicar no Botão Adicionar Gênero, o usuário é levado para a página de cadastro de gêneros
            Response.Redirect("CadastroGenero.aspx");
        }

        protected void Editar_Click(object sender, EventArgs e)
        {
            //o foreach verifica qual o item selecionado do grid, para fazer a edição do filme selecionado
            foreach (GridViewRow row in GridViewFilme.Rows)
            {
                //Verifica se o item está selecionado
                if ((row.FindControl("chkSelecionado") as CheckBox).Checked)
                {
                    //Pega o ID do item selecioando e coloca na variável ID
                    int ID = Convert.ToInt32(GridViewFilme.DataKeys[row.RowIndex].Value);

                    //Select do item selecionado utilizando LINQ
                    using (var context = new RegistroFilmesEntities())
                    {
                        var filme = (from f in context.Filme
                                     where f.ID == ID
                                     select f).FirstOrDefault();

                        //Coloca os valores do select nas variáveis de sessão para levar para a página cadastro de filmes
                        Session["ID"] = filme.ID;
                        Session["NomeFilme"] = filme.Nome;
                        Session["IDGenero"] = filme.IDGenero;
                        Session["DataCriacao"] = filme.DataCriacao;
                        Session["Ativo"] = filme.Ativo;

                    }
                    //Direciona o usuário a pagina de cadastro de filmes no modo EDIÇÃO.
                    Response.Redirect("CadastroFilmes_Edita.aspx");
                }      
            }
            //Caso nenhum item esteja seleciona, surge o popup com a mensagem
            System.Windows.Forms.MessageBox.Show("Selecione um filme para editar!");
        }

         protected void Excluir_Click(object sender, EventArgs e)
         {
            //o foreach verifica qual(is) itens estão selecionados no grid
             foreach (GridViewRow row in GridViewFilme.Rows)
             {
                //verifica se a row está selecionada
                 if ((row.FindControl("chkSelecionado") as CheckBox).Checked)
                 {
                    //Pega o ID do item selecioando e coloca na variável ID
                    int ID = Convert.ToInt32(GridViewFilme.DataKeys[row.RowIndex].Value);

                    //Select do item selecionado utilizando LINQ
                    using (var context = new RegistroFilmesEntities())
                     {
                         var filme = (from f in context.Filme
                                      where f.ID == ID
                                      select f).FirstOrDefault();

                         context.Filme.Remove(filme);
                         context.SaveChanges();
                     }

                     //Carrega o grid após os filmes selecionado serem excluídos
                     this.CarregaListaFilmes();
                     //Mostra popup com a mensagem
                     System.Windows.Forms.MessageBox.Show("Filme(s) excluído(s) com sucesso!");
                     // return para finalizar a execução
                     return;

                 }
             }
                 //Mostra mensagem no popup caso nenhum filme esteja selecionado.
                 System.Windows.Forms.MessageBox.Show("Selecione um filme para excluir!");
         }
            
    }
}