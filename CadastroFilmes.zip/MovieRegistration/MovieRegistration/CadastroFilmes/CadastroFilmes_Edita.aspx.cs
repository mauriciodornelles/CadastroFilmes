﻿using CadastroFilme;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace CadastroFilmes.CadastroFilmes
{
    public partial class CadastroFilmes_Edita : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Realiza trecho somente se não for primeira vez que a página é carregada
            if (!IsPostBack)
            {
                //Realiza carregamento do DropDown List Gênero com Nome dos Gêneros Cadastrados
                using (RegistroFilmesEntities context = new RegistroFilmesEntities())
                {
                    //Select utilizando LINQ
                    ddlGenero.DataSource = (from g in context.Genero
                                            select new { g.ID, g.Nome }).ToList();

                    ddlGenero.DataTextField = "Nome";
                    ddlGenero.DataValueField = "ID";
                    ddlGenero.DataBind();
                    ddlGenero.Items.Insert(0, new ListItem("Selecione um Gênero", "0")); //Adiciona à primera linha do DropDown List "Selecione um Gênero"

                }

                //Se for uma EDIÇÃO, carrega o Filme com o ID da sessão selecionado na tela de Lista
                if (Session["ID"] != null) 
                {
                    using (RegistroFilmesEntities context2 = new RegistroFilmesEntities())
                    {
                        int ID = Convert.ToInt32(Session["ID"]); //Coloca o valor do ID da Sessão dentro da variavél ID
                        var filme = context2.Filme.FirstOrDefault(x => x.ID == ID); //Select utilizando LINQ - Pegando a primeira linha onde o ID for igual ao ID procurado

                        //Carrega os campos com o filme buscado
                        txbNomeFilme.Text = filme.Nome;
                        ddlGenero.SelectedValue = Convert.ToInt32(filme.IDGenero).ToString();
                        txbDataCriacao.Text = Convert.ToDateTime(filme.DataCriacao).ToString("dd/MM/yyyy");
                        chkAtivo.Checked = filme.Ativo;

                    }
                }
                else //Se for Novo, carrega a tela com os campos limpos.
                {
                    txbNomeFilme.Text = "";
                    ddlGenero.SelectedValue = null;
                    txbDataCriacao.Text = "";
                    chkAtivo.Checked = false;
                }

            }
            
        }

        protected void Voltar_Click(object sender, EventArgs e)
        {
            //Limpa ID da sessão
            Session["ID"] = null;
            //Volta para Página Lista
            Response.Redirect("CadastroFilmes_lista.aspx");
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            //Salva o registro no novo filme
            RegistroFilmesEntities db = new RegistroFilmesEntities();

            //Testa a inserção dos dados
            try
            {
                Filme novoFilme = new Filme() // cria novo objeto Filme
                {
                    Nome = txbNomeFilme.Text,
                    IDGenero = Convert.ToInt32(ddlGenero.SelectedValue),
                    DataCriacao = Convert.ToDateTime(txbDataCriacao.Text),
                    Ativo = chkAtivo.Checked
                };
                db.Filme.Add(novoFilme);
                db.SaveChanges();

                MessageBox.Show("Filme salvo com sucesso!"); //Mostra Mensagem em um popup
            }
            catch (Exception ex) //Se houver erro durante a inserção dos dados, gera a exception
            {
                MessageBox.Show("Erro " + ex); //Mostra Mensagem do erro.
            }
        }
    }
}