﻿using CadastroFilme;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CadastroFilmes.CadastroFilmes
{
    public partial class CadastroGenero : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Realiza trecho somente se não for primeira vez que a página é carregada
            if (!IsPostBack)
            {
                //Se for uma EDIÇÃO, carrega o Gênero com o ID da sessão selecionado na tela de Lista
                if (Session["ID"] != null)
                {
                    using (RegistroFilmesEntities context2 = new RegistroFilmesEntities())
                    {
                        int ID = Convert.ToInt32(Session["ID"]); //Coloca o valor do ID da Sessão dentro da variavél ID
                        var genero = context2.Genero.FirstOrDefault(x => x.ID == ID); //Select utilizando LINQ - Pegando a primeira linha onde o ID for igual ao ID procurado

                        //Pega os dados inseridos para adicionar aos campos
                        txbGenero.Text = genero.Nome;
                        txbDataCriacao.Text = Convert.ToDateTime(genero.DataCriacao).ToString("dd/MM/yyyy");
                        chkAtivo.Checked = Convert.ToBoolean(genero.Ativo);

                    }
                }
                else //Se for um cadastro de NOVO Gênero, carrega a tela com os campos limpos
                {

                }

            }

        }

        protected void Voltar_Click(object sender, EventArgs e)
        {
            //Volta para tela de Lista
            Response.Redirect("CadastroFilmes_lista.aspx");
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            //Salva o registro no novo gênero
            RegistroFilmesEntities db = new RegistroFilmesEntities();

            try //Testa a inserção dos dados
            {
                Genero novoGenero = new Genero() //Cria novo objeto Genero
                {
                    Nome = txbGenero.Text,
                    DataCriacao = Convert.ToDateTime(txbDataCriacao.Text),
                    Ativo = chkAtivo.Checked
                };
                db.Genero.Add(novoGenero);
                db.SaveChanges();

                //Mostra Mensagem em um popup
                System.Windows.Forms.MessageBox.Show("Gênero salvo com sucesso!");
            }
            catch (Exception ex) //Se houver erro durante a inserção dos dados, gera a exception
            {
                System.Windows.Forms.MessageBox.Show("Erro " + ex); //Mostra Mensagem do erro.
            }
        }
    }
}