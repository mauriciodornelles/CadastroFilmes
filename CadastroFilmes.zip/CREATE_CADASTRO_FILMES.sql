CREATE TABLE Filme (
ID int IDENTITY(1,1) NOT NULL,
Nome varchar(50) NOT NULL UNIQUE,
DataCriacao datetime NULL,
Ativo bit NULL,
IDGenero int NULL,
PRIMARY KEY (ID)
)
GO

CREATE TABLE Genero (
ID int IDENTITY(1,1) NOT NULL,
Nome varchar(10) NOT NULL,
DataCriacao datetime NULL,
Ativo bit NULL,
PRIMARY KEY (ID)
)
GO

ALTER TABLE Filme ADD CONSTRAINT FK_FILME_GENERO FOREIGN KEY (IDGenero)
REFERENCES Genero (ID)
GO

insert into Genero (Nome, DataCriacao, Ativo) values ('C�media', getdate(), 1)
insert into Genero (Nome, DataCriacao, Ativo) values ('Romance', getdate(), 1)
insert into Genero (Nome, DataCriacao, Ativo) values ('Terror', getdate(), 1)
GO

insert into Filme (Nome, DataCriacao, Ativo, IDGenero) values ('Toc Toc', '20170605', 1, 1)
insert into Filme (Nome, DataCriacao, Ativo, IDGenero) values ('Crep�sculo', '20150405', 1, 2)
insert into Filme (Nome, DataCriacao, Ativo, IDGenero) values ('Exorcista', '20130112', 1, 3)
GO

