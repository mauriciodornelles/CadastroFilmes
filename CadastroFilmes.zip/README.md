Foi utilizado Visual Studio 2019;
.net framework 4.8 MVC;
Microsoft SQL Server Management Studio 18;
Entity Framework para as conexões de banco;
Bootstrap para os estilos;
Pasta CadastroFilmes contém os arquivos dos códigos
O arquivo CREATE_CADASTRO_FILMES.sql contém os scripts de criação das tabelas do banco
Ajustar a tag <connectionString> do arquivo web.config para as conexões de banco a serem utilizadas
